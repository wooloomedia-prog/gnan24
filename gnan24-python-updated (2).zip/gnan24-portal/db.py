from __future__ import annotations

import json
import os
import sqlite3
from datetime import datetime, timezone
from pathlib import Path

from data import ALL_ARTICLES

ROOT = Path(__file__).resolve().parent
DATABASE_OVERRIDE = os.getenv("DATABASE_PATH")
NEW_DATABASE_PATH = ROOT / "gnan24.db"
LEGACY_DATABASE_PATH = ROOT / "telugu_today.db"
if DATABASE_OVERRIDE:
    override_path = Path(DATABASE_OVERRIDE).expanduser()
    if not override_path.is_absolute():
        override_path = ROOT / override_path
    DB_PATH = (
        LEGACY_DATABASE_PATH
        if override_path == NEW_DATABASE_PATH and not override_path.exists() and LEGACY_DATABASE_PATH.exists()
        else override_path
    )
else:
    DB_PATH = (
        NEW_DATABASE_PATH
        if NEW_DATABASE_PATH.exists() or not LEGACY_DATABASE_PATH.exists()
        else LEGACY_DATABASE_PATH
    )

class ClosingConnection(sqlite3.Connection):
    def __exit__(self, exc_type, exc_value, traceback):
        try:
            return super().__exit__(exc_type, exc_value, traceback)
        finally:
            self.close()


def connect() -> sqlite3.Connection:
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    connection = sqlite3.connect(DB_PATH, timeout=15, factory=ClosingConnection)
    connection.row_factory = sqlite3.Row
    connection.execute("PRAGMA foreign_keys = ON")
    return connection


def initialize_database() -> None:
    with connect() as db:
        db.executescript((ROOT / "schema.sql").read_text(encoding="utf-8"))
        existing = {row["name"] for row in db.execute("PRAGMA table_info(articles)")}
        additions = {
            "read_time": "TEXT DEFAULT '4 min read'",
            "time_label": "TEXT DEFAULT 'ఇప్పుడే'",
            "tag": "TEXT DEFAULT ''",
        }
        for column, definition in additions.items():
            if column not in existing:
                db.execute(f"ALTER TABLE articles ADD COLUMN {column} {definition}")

        for article in ALL_ARTICLES:
            db.execute(
                """
                INSERT OR IGNORE INTO articles
                (slug, title, category, category_slug, summary, body, image, author,
                 status, featured, breaking, read_time, time_label, tag)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'PUBLISHED', ?, ?, ?, ?, ?)
                """,
                (
                    article["slug"], article["title"], article["category"], article["category_slug"],
                    article["summary"], json.dumps(article["body"], ensure_ascii=False), article["image"],
                    article["author"], int(article["featured"]), int(article["breaking"]),
                    article["read_time"], article["time"], article["tag"],
                ),
            )
        placements = (
            "TOP_BANNER", "HEADER_BANNER", "BETWEEN_NAV", "BREAKING_NEWS", "HERO_RIGHT",
            "SIDEBAR_TOP", "SIDEBAR_MIDDLE", "ARTICLE_TOP", "ARTICLE_MIDDLE",
            "ARTICLE_BOTTOM", "CATEGORY_TOP", "FOOTER", "MOBILE_STICKY", "DESKTOP_STICKY",
        )
        for placement in placements:
            db.execute("INSERT OR IGNORE INTO ad_placements (placement_key, enabled) VALUES (?, 1)", (placement,))
        default_settings = {
            "site_name": "gnan24",
            "contact_email": "editor@gnan24.example",
            "seo_title": "gnan24 — Truth, People, Progress",
            "seo_description": "Regional news, analysis, sports, and entertainment for readers across India.",
            "timezone": "Asia/Kolkata",
            "breaking_enabled": "1",
            "comments_enabled": "1",
            "registration_enabled": "1",
        }
        for key, value in default_settings.items():
            db.execute("INSERT OR IGNORE INTO site_settings (key, value) VALUES (?, ?)", (key, value))
        db.execute("UPDATE site_settings SET value='gnan24' WHERE key='site_name' AND value='Telugu Today'")
        db.execute(
            "UPDATE site_settings SET value='gnan24 — Truth, People, Progress' "
            "WHERE key='seo_title' AND value='Telugu Today — నిజమైన కథలు, మీ ప్రపంచం'"
        )
        db.execute(
            "UPDATE site_settings SET value='gnan24 — Truth, People, Progress' "
            "WHERE key='seo_title' AND value='gnan24 — తెలుగు వార్తలు, మీ ప్రపంచం'"
        )
        db.execute(
            "UPDATE site_settings SET value='Regional news, analysis, sports, and entertainment for readers across India.' "
            "WHERE key='seo_description' AND value='తెలుగు పాఠకుల కోసం ప్రాంతీయ వార్తలు, విశ్లేషణలు, క్రీడలు మరియు వినోదం.'"
        )
        db.execute(
            "UPDATE articles SET author='gnan24 Desk' WHERE author IN ('తెలుగు టుడే డెస్క్', 'gnan24 డెస్క్')"
        )
        db.execute("UPDATE articles SET read_time=replace(read_time, ' నిమిషాల చదువు', ' min read') WHERE read_time LIKE '%నిమిషాల చదువు%'")
        db.execute("UPDATE ad_campaigns SET name='City Food Festival' WHERE name='సిటీ ఫుడ్ ఫెస్టివల్'")
        campaign_count = db.execute("SELECT COUNT(*) FROM ad_campaigns").fetchone()[0]
        if not campaign_count:
            for name, advertiser, placement, status, revenue in [
                ("ABC Electronics", "ABC Electronics", "HEADER_BANNER", "ACTIVE", 124800),
                ("City Food Festival", "City Food Festival", "ARTICLE_MIDDLE", "ACTIVE", 68400),
                ("LearnPro Academy", "LearnPro Academy", "SIDEBAR_TOP", "PAUSED", 42200),
            ]:
                db.execute(
                    """INSERT INTO ad_campaigns
                    (name, advertiser, placement, start_date, end_date, status, revenue)
                    VALUES (?, ?, ?, ?, ?, ?, ?)""",
                    (name, advertiser, placement, "2026-09-01", "2026-10-31", status, revenue),
                )


def row_to_article(row: sqlite3.Row) -> dict:
    keys = set(row.keys())
    try:
        body = json.loads(row["body"] or "[]")
    except (json.JSONDecodeError, TypeError):
        body = [row["summary"]]
    if isinstance(body, str):
        body = [body]
    return {
        "id": str(row["id"]),
        "slug": row["slug"],
        "title": row["title"],
        "category": row["category"],
        "category_slug": row["category_slug"],
        "summary": row["summary"],
        "body": body,
        "image": row["image"] or "",
        "author": row["author"] or "gnan24 Desk",
        "status": row["status"] if "status" in keys else "PUBLISHED",
        "featured": bool(row["featured"]),
        "breaking": bool(row["breaking"]),
        "read_time": row["read_time"] or "4 min read",
        "time": row["time_label"] or "ఇప్పుడే",
        "tag": row["tag"] or "",
    }


def get_articles(include_unpublished: bool = False) -> list[dict]:
    with connect() as db:
        if include_unpublished:
            rows = db.execute(
                "SELECT * FROM articles ORDER BY created_at DESC, id DESC"
            ).fetchall()
        else:
            rows = db.execute(
                "SELECT * FROM articles WHERE status = 'PUBLISHED' ORDER BY featured DESC, created_at DESC, id DESC"
            ).fetchall()
    return [row_to_article(row) for row in rows]


def get_article(slug: str) -> dict | None:
    with connect() as db:
        row = db.execute("SELECT * FROM articles WHERE slug = ?", (slug,)).fetchone()
    return row_to_article(row) if row else None


def save_article(form: dict, existing_slug: str | None = None) -> str:
    title = form.get("title", "").strip()
    category = form.get("category", "").strip()
    category_slug = form.get("category_slug", "").strip()
    summary = form.get("summary", "").strip()
    body_value = form.get("body", "")
    if isinstance(body_value, (list, tuple)):
        body_text = "\n\n".join(str(paragraph) for paragraph in body_value)
    else:
        body_text = str(body_value).strip()
    if not title or not category or not category_slug or not summary or not body_text:
        raise ValueError("Title, category, summary, and article body are required.")
    slug = form.get("slug", "").strip()
    if not slug:
        slug = "-".join(title.split())[:90]
    slug = "".join(char if char.isalnum() or char in "-_" else "-" for char in slug.lower())
    status = form.get("status", "DRAFT").upper()
    if status not in {"DRAFT", "PUBLISHED", "SCHEDULED"}:
        status = "DRAFT"
    now = datetime.now(timezone.utc).isoformat()
    body = [line.strip() for line in body_text.splitlines() if line.strip()]
    if not body:
        body = [summary]
    values = (
        slug, title, category, category_slug, summary, json.dumps(body, ensure_ascii=False),
        form.get("image", "").strip(), form.get("author", "").strip() or "gnan24 Desk",
        status, int(form.get("featured") == "on"), int(form.get("breaking") == "on"),
        form.get("read_time", "").strip() or "4 min read", "ఇప్పుడే",
        form.get("tag", "").strip(),
    )
    with connect() as db:
        collision = db.execute("SELECT slug FROM articles WHERE slug = ?", (slug,)).fetchone()
        if collision and slug != existing_slug:
            slug = f"{slug}-{int(datetime.now().timestamp())}"
            values = (slug, *values[1:])
        if existing_slug:
            db.execute(
                """UPDATE articles SET slug=?, title=?, category=?, category_slug=?, summary=?, body=?,
                image=?, author=?, status=?, featured=?, breaking=?, read_time=?, time_label=?, tag=?,
                created_at=CURRENT_TIMESTAMP WHERE slug=?""",
                (*values, existing_slug),
            )
        else:
            db.execute(
                """INSERT INTO articles
                (slug,title,category,category_slug,summary,body,image,author,status,featured,breaking,read_time,time_label,tag)
                VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                values,
            )
    return slug


def change_article_status(slug: str, status: str) -> bool:
    if status not in {"DRAFT", "PUBLISHED", "SCHEDULED"}:
        return False
    with connect() as db:
        cursor = db.execute("UPDATE articles SET status=? WHERE slug=?", (status, slug))
    return cursor.rowcount > 0


def delete_article(slug: str) -> bool:
    with connect() as db:
        cursor = db.execute("DELETE FROM articles WHERE slug=?", (slug,))
    return cursor.rowcount > 0


def get_campaigns() -> list[dict]:
    with connect() as db:
        campaigns = [dict(row) for row in db.execute("SELECT * FROM ad_campaigns ORDER BY id DESC")]
        placements = [dict(row) for row in db.execute("SELECT * FROM ad_placements ORDER BY placement_key")]
    return {"campaigns": campaigns, "placements": placements}


def save_campaign(form: dict) -> None:
    name = form.get("name", "").strip()
    advertiser = form.get("advertiser", "").strip()
    placement = form.get("placement", "").strip()
    if not name or not advertiser or not placement:
        raise ValueError("Campaign name, advertiser, and placement are required.")
    status = form.get("status", "ACTIVE").upper()
    if status not in {"ACTIVE", "PAUSED", "SCHEDULED"}:
        status = "ACTIVE"
    with connect() as db:
        db.execute(
            """INSERT INTO ad_campaigns
            (name, advertiser, placement, start_date, end_date, status, destination_url, revenue)
            VALUES (?, ?, ?, ?, ?, ?, ?, 0)""",
            (
                name, advertiser, placement, form.get("start_date", ""),
                form.get("end_date", ""), status, form.get("destination_url", "").strip(),
            ),
        )


def campaign_action(campaign_id: int, action: str) -> bool:
    with connect() as db:
        if action in {"pause", "activate"}:
            status = "PAUSED" if action == "pause" else "ACTIVE"
            cursor = db.execute("UPDATE ad_campaigns SET status=? WHERE id=?", (status, campaign_id))
        elif action == "delete":
            cursor = db.execute("DELETE FROM ad_campaigns WHERE id=?", (campaign_id,))
        else:
            return False
    return cursor.rowcount > 0


def set_placement(placement: str, enabled: bool) -> None:
    with connect() as db:
        db.execute(
            """INSERT INTO ad_placements (placement_key, enabled) VALUES (?, ?)
            ON CONFLICT(placement_key) DO UPDATE SET enabled=excluded.enabled""",
            (placement, int(enabled)),
        )


def get_settings() -> dict[str, str]:
    with connect() as db:
        rows = db.execute("SELECT key, value FROM site_settings").fetchall()
    return {row["key"]: row["value"] for row in rows}


def save_settings(form: dict) -> None:
    values = {
        "site_name": form.get("site_name", "gnan24").strip(),
        "contact_email": form.get("contact_email", "").strip(),
        "seo_title": form.get("seo_title", "").strip(),
        "seo_description": form.get("seo_description", "").strip(),
        "timezone": form.get("timezone", "Asia/Kolkata").strip(),
        "breaking_enabled": "1" if form.get("breaking_enabled") == "on" else "0",
        "comments_enabled": "1" if form.get("comments_enabled") == "on" else "0",
        "registration_enabled": "1" if form.get("registration_enabled") == "on" else "0",
    }
    with connect() as db:
        db.executemany(
            """INSERT INTO site_settings (key, value) VALUES (?, ?)
            ON CONFLICT(key) DO UPDATE SET value=excluded.value""",
            values.items(),
        )


def log_event(event_type: str, page: str = "", device: str = "") -> None:
    with connect() as db:
        db.execute(
            "INSERT INTO analytics_events (event_type, page, device) VALUES (?, ?, ?)",
            (event_type, page[:250], device[:80]),
        )