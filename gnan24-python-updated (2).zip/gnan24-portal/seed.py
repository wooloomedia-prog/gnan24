"""Initialize or safely seed the local SQLite database."""

from db import DB_PATH, get_articles, initialize_database

initialize_database()
print(f"Database ready: {DB_PATH}")
print(f"Articles currently stored: {len(get_articles(include_unpublished=True))}")