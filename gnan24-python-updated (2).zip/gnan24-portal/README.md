# gnan24 — Python News Portal

Standalone Flask version of the gnan24 news portal. This edition avoids Node.js and npm entirely. The CMS article, ad campaign, ad placement, and settings actions now persist in SQLite.

The supplied gnan24 logo appears left-aligned in the public header. The public site uses a newspaper-style lead story, latest-news list, section grids, and media cards. Admin navigation, controls, settings, and notices are in English; Telugu article text remains as editorial content.

## Run

```bash
python -m venv .venv
# macOS/Linux
source .venv/bin/activate
# Windows PowerShell
# .venv\Scripts\Activate.ps1

pip install -r requirements.txt
python seed.py
python app.py
```

Open `http://localhost:5000`.

The first app start initializes `gnan24.db` beside the source, seeds 54 fictional articles, and creates the placement/settings records. `python seed.py` can also initialize or update the database explicitly. Public pages load published stories from SQLite; the admin list includes drafts and scheduled stories. When upgrading an earlier package, the app continues using its existing `telugu_today.db` if it is present and migrates the old default brand settings to gnan24.

Run the included workflow tests with:

```bash
python -m unittest discover -s tests -v
```

These cover article create/edit/publish/unpublish/delete, API persistence, ad campaign state and placement switches, settings saves, and primary routes.

## Routes

Public: `/`, `/andhra-pradesh`, `/telangana`, `/hyderabad`, `/politics`, `/business`, `/sports`, `/cinema`, `/technology`, `/education`, `/jobs`, `/lifestyle`, `/health`, `/search`, `/epaper`, `/photos`, `/videos`

Articles: `/news/<category>/<slug>`

CMS: `/admin`, `/admin/articles`, `/admin/ads`, `/admin/settings`

CMS actions: create/edit/publish/unpublish/delete articles; create/pause/resume/delete campaigns; save ad placement switches; save site settings. Article images can be uploaded as PNG, JPG, GIF, or WebP files up to 5 MB, or entered as a URL.

API: `GET /api/search?q=`, `GET /api/articles?category=&page=`, `POST /api/articles` (creates a persistent draft or requested status)

## Replit

Create a Python Repl, upload/extract this folder, then run:

```bash
pip install -r requirements.txt
python app.py
```

The app listens on `0.0.0.0:5000` and reads `PORT` when supplied. Configure `SECRET_KEY` and other values from `.env.example` for deployment.

## Production notes

The CMS is a functional local demo, not a production-secured newsroom. It currently has no login gate, so do not expose `/admin` publicly. Before deployment, add real authentication/roles, CSRF protection, upload validation, PostgreSQL/object storage, and connect campaign ads to an ad network. Settings and ad inventory are persisted locally; billing/revenue values are demo estimates.