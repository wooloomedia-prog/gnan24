CREATE TABLE IF NOT EXISTS articles (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  slug TEXT UNIQUE NOT NULL,
  title TEXT NOT NULL,
  category TEXT NOT NULL,
  category_slug TEXT NOT NULL,
  summary TEXT NOT NULL,
  body TEXT NOT NULL,
  image TEXT,
  author TEXT,
  status TEXT DEFAULT 'PUBLISHED',
  featured INTEGER DEFAULT 0,
  breaking INTEGER DEFAULT 0,
  read_time TEXT DEFAULT '4 min read',
  time_label TEXT DEFAULT 'ఇప్పుడే',
  tag TEXT DEFAULT '',
  created_at TEXT DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS ad_placements (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  placement_key TEXT UNIQUE NOT NULL,
  enabled INTEGER DEFAULT 1
);

CREATE TABLE IF NOT EXISTS ad_campaigns (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  advertiser TEXT NOT NULL,
  placement TEXT NOT NULL,
  start_date TEXT,
  end_date TEXT,
  status TEXT DEFAULT 'ACTIVE',
  destination_url TEXT,
  revenue REAL DEFAULT 0,
  created_at TEXT DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS site_settings (
  key TEXT PRIMARY KEY,
  value TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS analytics_events (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  event_type TEXT NOT NULL,
  page TEXT,
  device TEXT,
  created_at TEXT DEFAULT CURRENT_TIMESTAMP
);