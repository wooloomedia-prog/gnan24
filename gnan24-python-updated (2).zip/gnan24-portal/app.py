from __future__ import annotations

import os
import uuid
from datetime import datetime
from pathlib import Path
from urllib.parse import quote

from flask import Flask, flash, jsonify, redirect, render_template, request, url_for
from dotenv import load_dotenv
from werkzeug.utils import secure_filename

BASE_DIR = Path(__file__).resolve().parent
load_dotenv(BASE_DIR / ".env")

from data import CATEGORIES, DISTRICTS, SITE
from db import (
    change_article_status,
    campaign_action,
    delete_article,
    get_article,
    get_articles,
    get_campaigns,
    get_settings,
    initialize_database,
    log_event,
    save_article,
    save_campaign,
    save_settings,
    set_placement,
)

app = Flask(__name__)
app.config["SECRET_KEY"] = os.getenv("SECRET_KEY", "development-only-change-me")
app.config["MAX_CONTENT_LENGTH"] = 5 * 1024 * 1024
app.config["UPLOAD_FOLDER"] = str(BASE_DIR / "static" / "uploads")
initialize_database()

ADMIN_CATEGORY_LABELS = {
    "ఆంధ్రప్రదేశ్": "Andhra Pradesh",
    "తెలంగాణ": "Telangana",
    "హైదరాబాద్": "Hyderabad",
    "జాతీయం": "National",
    "అంతర్జాతీయం": "International",
    "రాజకీయాలు": "Politics",
    "బిజినెస్": "Business",
    "క్రీడలు": "Sports",
    "సినిమా": "Cinema",
    "టెక్నాలజీ": "Technology",
    "విద్య": "Education",
    "ఉద్యోగాలు": "Jobs",
    "లైఫ్‌స్టైల్": "Lifestyle",
    "ఆరోగ్యం": "Health",
}


def article_url(article: dict) -> str:
    return url_for("article", category=article["category_slug"], slug=article["slug"])


@app.template_filter("article_url")
def article_url_filter(article: dict) -> str:
    return article_url(article)


@app.template_filter("admin_read_time")
def admin_read_time(value: str) -> str:
    text = value or "4 min read"
    return text.replace(" నిమిషాల చదువు", " min read")


def save_uploaded_image(upload) -> tuple[str, Path]:
    try:
        safe_name = secure_filename(upload.filename or "")
        extension = Path(safe_name).suffix.lower()
        header = upload.stream.read(12)
        upload.stream.seek(0)
        valid_signatures = {
            ".png": header.startswith(b"\x89PNG\r\n\x1a\n"),
            ".jpg": header.startswith(b"\xff\xd8\xff"),
            ".jpeg": header.startswith(b"\xff\xd8\xff"),
            ".gif": header.startswith((b"GIF87a", b"GIF89a")),
            ".webp": header[:4] == b"RIFF" and header[8:12] == b"WEBP",
        }
        if extension not in valid_signatures or not valid_signatures[extension]:
            raise ValueError("Choose a valid PNG, JPG, GIF, or WebP image.")
        destination_dir = Path(app.config["UPLOAD_FOLDER"])
        destination_dir.mkdir(parents=True, exist_ok=True)
        destination = destination_dir / f"{uuid.uuid4().hex}{extension}"
        upload.save(destination)
        return f"/static/uploads/{destination.name}", destination
    finally:
        upload.close()


@app.context_processor
def global_template_values():
    settings = get_settings()
    stories = get_articles()
    placements = get_campaigns()["placements"]
    return {
        "site": {**SITE, "name": settings.get("site_name", SITE["name"])},
        "nav_items": CATEGORIES,
        "admin_categories": [
            {**item, "admin_label": ADMIN_CATEGORY_LABELS.get(item["label"], item["label"])}
            for item in CATEGORIES
        ],
        "admin_category_labels": ADMIN_CATEGORY_LABELS,
        "today": "బుధవారం, సెప్టెంబర్ 30, 2026",
        "breaking": [item for item in stories if item["breaking"]][:4],
        "breaking_enabled": settings.get("breaking_enabled", "1") == "1",
        "ad_enabled": lambda key: next((bool(p["enabled"]) for p in placements if p["placement_key"] == key), True),
        "site_settings": settings,
    }


@app.before_request
def record_page_view():
    if request.method == "GET" and not request.path.startswith("/static/"):
        user_agent = request.headers.get("User-Agent", "")
        device = "mobile" if "mobile" in user_agent.lower() else "desktop"
        log_event("PAGE_VIEW", request.path, device)


@app.get("/")
def home():
    stories = get_articles()
    if not stories:
        stories = []
    return render_template(
        "home.html",
        hero=stories[0] if stories else None,
        secondary=stories[1:6],
        latest=stories[4:9],
        popular=stories[3:8],
        ap_stories=[a for a in stories if a["category_slug"] in {"andhra-pradesh", "hyderabad"}][:3],
        telangana_stories=[a for a in stories if a["category_slug"] in {"technology", "national"}][:3],
        national=[a for a in stories if a["category_slug"] in {"national", "international", "politics", "business"}][:3],
        sports=[a for a in stories if a["category_slug"] == "sports"][:3],
        culture=[a for a in stories if a["category_slug"] in {"cinema", "technology", "lifestyle"}][:3],
        districts=DISTRICTS,
        featured_videos=stories[2:5],
        photo_stories=stories[5:8],
    )


@app.get("/news/<category>/<slug>")
def article(category: str, slug: str):
    story = get_article(slug)
    if not story or story["status"] != "PUBLISHED":
        return render_template("not_found.html"), 404
    related = [
        item for item in get_articles()
        if item["id"] != story["id"] and item["category_slug"] == story["category_slug"]
    ][:3]
    return render_template("article.html", article=story, related=related, popular=get_articles()[2:7])


@app.get("/search")
def search():
    query = request.args.get("q", "").strip()
    needle = query.lower()
    results = [
        item for item in get_articles()
        if not needle
        or needle in item["title"].lower()
        or needle in item["summary"].lower()
        or needle in item["category"].lower()
    ]
    return render_template("search.html", query=query, results=results[:20])


@app.get("/<category>")
def category(category: str):
    category_info = next((item for item in CATEGORIES if item["slug"] == category), None)
    if not category_info:
        return render_template("not_found.html"), 404
    stories = [item for item in get_articles() if item["category_slug"] == category]
    return render_template(
        "category.html",
        category=category_info,
        stories=stories,
        more=get_articles()[8:14],
    )


@app.get("/epaper")
def epaper():
    return render_template("epaper.html")


@app.get("/photos")
def photos():
    return render_template("photos.html", photos=get_articles()[1:10])


@app.get("/videos")
def videos():
    return render_template("videos.html", videos=get_articles()[2:11])


@app.get("/admin")
def admin():
    articles = get_articles(include_unpublished=True)
    published = sum(item["status"] == "PUBLISHED" for item in articles)
    drafts = sum(item["status"] == "DRAFT" for item in articles)
    events = _event_count("PAGE_VIEW")
    metrics = [
        ("Total articles", str(len(articles)), "In database"),
        ("Published articles", str(published), "Live"),
        ("Drafts", str(drafts), "In progress"),
        ("Page views", str(events), "This app session"),
        ("Ad campaigns", str(len(get_campaigns()["campaigns"])), "In database"),
    ]
    return render_template("admin.html", metrics=metrics, admin_articles=articles[:6])


@app.get("/admin/articles")
def admin_articles():
    query = request.args.get("q", "").strip().lower()
    status = request.args.get("status", "")
    articles = get_articles(include_unpublished=True)
    if query:
        articles = [
            a for a in articles
            if query in f'{a["title"]} {ADMIN_CATEGORY_LABELS.get(a["category"], a["category"])} {a["author"]}'.lower()
        ]
    if status:
        articles = [a for a in articles if a["status"] == status]
    return render_template("admin_articles.html", admin_articles=articles, query=query, selected_status=status)


@app.get("/admin/articles/new")
def new_admin_article():
    return render_template("article_form.html", article=None)


@app.get("/admin/articles/<slug>/edit")
def edit_admin_article(slug: str):
    story = get_article(slug)
    if not story:
        return render_template("admin_not_found.html"), 404
    return render_template("article_form.html", article=story)


@app.post("/admin/articles/save")
def admin_article_save():
    existing_slug = request.form.get("existing_slug") or None
    existing_article = get_article(existing_slug) if existing_slug else None
    uploaded_path = None
    form_data = request.form.to_dict()
    try:
        upload = request.files.get("image_file")
        if upload and upload.filename:
            image_url, uploaded_path = save_uploaded_image(upload)
        elif upload:
            upload.close()
        elif request.form.get("remove_image") == "on":
            image_url = ""
        else:
            image_url = request.form.get("image_url", request.form.get("image", "")).strip()
            if not image_url and existing_article:
                image_url = existing_article["image"]
        form_data["image"] = image_url
        slug = save_article(form_data, existing_slug)
    except ValueError as error:
        if uploaded_path:
            uploaded_path.unlink(missing_ok=True)
        flash(str(error), "error")
        return redirect(url_for("edit_admin_article", slug=existing_slug) if existing_slug else url_for("new_admin_article"))
    flash("Article saved successfully.", "success")
    return redirect(url_for("admin_articles"))


@app.errorhandler(413)
def upload_too_large(_error):
    return "Image upload exceeds the 5 MB limit. Choose a smaller image and try again.", 413


@app.post("/admin/articles/<slug>/action")
def admin_article_action(slug: str):
    action = request.form.get("action")
    if action == "delete":
        delete_article(slug)
        flash("Article deleted.", "success")
    elif action == "publish":
        change_article_status(slug, "PUBLISHED")
        flash("Article published.", "success")
    elif action == "unpublish":
        change_article_status(slug, "DRAFT")
        flash("Article moved to drafts.", "success")
    return redirect(url_for("admin_articles"))


@app.get("/admin/ads")
def admin_ads():
    ads = get_campaigns()
    return render_template("admin_ads.html", campaigns=ads["campaigns"], placements=ads["placements"])


@app.post("/admin/ads/create")
def admin_ads_create():
    try:
        save_campaign(request.form)
    except ValueError as error:
        flash(str(error), "error")
    else:
        flash("Ad campaign created.", "success")
    return redirect(url_for("admin_ads"))


@app.post("/admin/ads/<int:campaign_id>/action")
def admin_ads_action(campaign_id: int):
    action = request.form.get("action", "")
    if campaign_action(campaign_id, action):
        flash("Campaign updated.", "success")
    else:
        flash("Campaign action failed.", "error")
    return redirect(url_for("admin_ads"))


@app.post("/admin/ads/placements")
def admin_ads_placements():
    all_keys = [row["placement_key"] for row in get_campaigns()["placements"]]
    enabled = set(request.form.getlist("enabled"))
    for key in all_keys:
        set_placement(key, key in enabled)
    flash("Ad placements updated.", "success")
    return redirect(url_for("admin_ads"))


@app.get("/admin/settings")
def admin_settings():
    return render_template("admin_settings.html", settings=get_settings())


@app.post("/admin/settings/save")
def admin_settings_save():
    save_settings(request.form)
    flash("Settings saved.", "success")
    return redirect(url_for("admin_settings"))


@app.get("/api/search")
def api_search():
    query = request.args.get("q", "").strip().lower()
    results = [
        item for item in get_articles()
        if not query or query in f'{item["title"]} {item["summary"]} {item["category"]}'.lower()
    ]
    return jsonify({"query": request.args.get("q", ""), "total": len(results), "results": results[:20]})


@app.get("/api/articles")
def api_articles():
    category_filter = request.args.get("category")
    try:
        page = max(1, int(request.args.get("page", 1)))
        page_size = min(50, max(1, int(request.args.get("page_size", 12))))
    except ValueError:
        return jsonify({"error": "page and page_size must be integers"}), 400
    records = [item for item in get_articles() if not category_filter or item["category_slug"] == category_filter]
    start = (page - 1) * page_size
    return jsonify({
        "data": records[start:start + page_size],
        "page": page,
        "page_size": page_size,
        "total": len(records),
        "total_pages": (len(records) + page_size - 1) // page_size,
    })


@app.post("/api/articles")
def create_article():
    payload = request.get_json(silent=True) or {}
    payload = {
        "title": payload.get("title", ""),
        "category": payload.get("category", ""),
        "category_slug": payload.get("category_slug", ""),
        "summary": payload.get("summary", ""),
        "body": payload.get("body", ""),
        "image": payload.get("image", ""),
        "author": payload.get("author", ""),
        "status": payload.get("status", "DRAFT"),
        "featured": "on" if payload.get("featured") else "",
        "breaking": "on" if payload.get("breaking") else "",
        "tag": payload.get("tag", ""),
        "slug": payload.get("slug", ""),
    }
    if not payload["category_slug"]:
        payload["category_slug"] = next(
            (item["slug"] for item in CATEGORIES if item["label"] == payload["category"]),
            "",
        )
    try:
        slug = save_article(payload)
    except ValueError as error:
        return jsonify({"error": str(error)}), 400
    return jsonify({"message": "Article saved", "article": get_article(slug)}), 201


@app.get("/sitemap.xml")
def sitemap():
    urls = [url_for("home", _external=True)]
    urls += [url_for("category", category=item["slug"], _external=True) for item in CATEGORIES]
    urls += [article_url(item) for item in get_articles()[:20]]
    body = '<?xml version="1.0" encoding="UTF-8"?>\n'
    body += '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">'
    body += "".join(f"<url><loc>{quote(url, safe=':/?=&')}</loc></url>" for url in urls)
    body += "</urlset>"
    return app.response_class(body, mimetype="application/xml")


@app.get("/robots.txt")
def robots():
    return app.response_class(
        f"User-agent: *\nAllow: /\nSitemap: {url_for('sitemap', _external=True)}\n",
        mimetype="text/plain",
    )


def _event_count(event_type: str) -> int:
    from db import connect

    with connect() as db:
        return int(db.execute("SELECT COUNT(*) FROM analytics_events WHERE event_type=?", (event_type,)).fetchone()[0])


if __name__ == "__main__":
    app.run(host=os.getenv("HOST", "0.0.0.0"), port=int(os.getenv("PORT", "5000")), debug=os.getenv("FLASK_DEBUG") == "1")