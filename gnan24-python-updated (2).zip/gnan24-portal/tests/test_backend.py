import base64
import os
import re
import tempfile
import unittest
from io import BytesIO
from pathlib import Path

TEMP_DB = tempfile.TemporaryDirectory(prefix="gnan24-tests-")
os.environ["DATABASE_PATH"] = str(Path(TEMP_DB.name) / "test.db")

import db
from app import app


class BackendWorkflowTests(unittest.TestCase):
    @classmethod
    def tearDownClass(cls):
        TEMP_DB.cleanup()

    def setUp(self):
        db.DB_PATH = Path(TEMP_DB.name) / f"test-{self._testMethodName}.db"
        if db.DB_PATH.exists():
            db.DB_PATH.unlink()
        db.initialize_database()
        app.testing = True
        self.client = app.test_client()

    def test_article_create_publish_unpublish_delete(self):
        created = self.client.post("/admin/articles/save", data={
            "title": "QA కథనం — కొత్తది",
            "category": "హైదరాబాద్",
            "category_slug": "hyderabad",
            "summary": "సారాంశం",
            "body": "మొదటి పేరా\n\nరెండవ పేరా",
            "author": "QA Reporter",
            "status": "DRAFT",
        }, follow_redirects=True)
        self.assertEqual(created.status_code, 200)
        article = next(a for a in db.get_articles(True) if a["title"] == "QA కథనం — కొత్తది")
        self.assertEqual(article["status"], "DRAFT")
        self.assertEqual(self.client.get(f"/news/hyderabad/{article['slug']}").status_code, 404)

        self.client.post(f"/admin/articles/{article['slug']}/action", data={"action": "publish"})
        self.assertEqual(self.client.get(f"/news/hyderabad/{article['slug']}").status_code, 200)
        self.client.post(f"/admin/articles/{article['slug']}/action", data={"action": "unpublish"})
        self.assertEqual(self.client.get(f"/news/hyderabad/{article['slug']}").status_code, 404)
        self.client.post(f"/admin/articles/{article['slug']}/action", data={"action": "delete"})
        self.assertIsNone(db.get_article(article["slug"]))

    def test_edit_and_api_create_are_persistent(self):
        created = self.client.post("/api/articles", json={
            "title": "API QA కథనం",
            "category": "క్రీడలు",
            "category_slug": "sports",
            "summary": "API summary",
            "body": ["Paragraph 1", "Paragraph 2"],
            "status": "PUBLISHED",
        })
        self.assertEqual(created.status_code, 201)
        article = db.get_article(created.json["article"]["slug"])
        self.assertEqual(article["body"], ["Paragraph 1", "Paragraph 2"])

        self.client.post("/admin/articles/save", data={
            "existing_slug": article["slug"],
            "slug": article["slug"],
            "title": "API QA సవరించిన కథనం",
            "category": "క్రీడలు",
            "category_slug": "sports",
            "summary": "మార్చిన సారాంశం",
            "body": "మార్చిన పేరా",
            "status": "PUBLISHED",
        })
        self.assertIsNotNone(db.get_article(article["slug"]))
        self.assertEqual(db.get_article(article["slug"])["title"], "API QA సవరించిన కథనం")

    def test_article_image_file_upload(self):
        image_bytes = base64.b64decode(
            "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+jMT8AAAAASUVORK5CYII="
        )
        response = self.client.post("/admin/articles/save", data={
            "title": "Uploaded image test",
            "category": "హైదరాబాద్",
            "category_slug": "hyderabad",
            "summary": "Upload test summary",
            "body": "Upload test body",
            "status": "DRAFT",
            "image_file": (BytesIO(image_bytes), "news-image.png"),
        })
        self.assertEqual(response.status_code, 302)
        response.close()
        article = next(a for a in db.get_articles(True) if a["title"] == "Uploaded image test")
        self.assertTrue(article["image"].startswith("/static/uploads/"))
        uploaded_path = Path(app.static_folder) / article["image"].removeprefix("/static/")
        self.assertTrue(uploaded_path.is_file())
        served_image = self.client.get(article["image"])
        self.assertEqual(served_image.status_code, 200)
        served_image.close()
        uploaded_path.unlink()

    def test_article_upload_rejects_non_image_files(self):
        response = self.client.post("/admin/articles/save", data={
            "title": "Invalid upload test",
            "category": "హైదరాబాద్",
            "category_slug": "hyderabad",
            "summary": "Upload validation test",
            "body": "This is not an image.",
            "image_file": (BytesIO(b"not an image"), "payload.exe"),
        }, follow_redirects=True)
        self.assertEqual(response.status_code, 200)
        self.assertIn("Choose a valid PNG, JPG, GIF, or WebP image.", response.data.decode("utf-8"))
        self.assertFalse(any(a["title"] == "Invalid upload test" for a in db.get_articles(True)))
        response.close()

    def test_campaign_placement_and_settings_save(self):
        self.client.post("/admin/ads/create", data={
            "name": "QA Campaign", "advertiser": "QA",
            "placement": "TOP_BANNER", "status": "ACTIVE",
            "start_date": "2026-01-01", "end_date": "2026-12-31",
        })
        campaign = next(c for c in db.get_campaigns()["campaigns"] if c["name"] == "QA Campaign")
        self.client.post(f"/admin/ads/{campaign['id']}/action", data={"action": "pause"})
        campaign = next(c for c in db.get_campaigns()["campaigns"] if c["id"] == campaign["id"])
        self.assertEqual(campaign["status"], "PAUSED")

        self.client.post("/admin/ads/placements", data={"enabled": ["HEADER_BANNER"]})
        placements = {p["placement_key"]: p["enabled"] for p in db.get_campaigns()["placements"]}
        self.assertEqual(placements["TOP_BANNER"], 0)
        self.assertEqual(placements["HEADER_BANNER"], 1)
        self.assertNotIn("TOP BANNER", self.client.get("/").data.decode("utf-8"))

        self.client.post("/admin/settings/save", data={
            "site_name": "QA News",
            "contact_email": "qa@example.test",
            "seo_title": "QA title",
            "seo_description": "QA description",
            "timezone": "UTC",
        })
        settings = db.get_settings()
        self.assertEqual(settings["site_name"], "QA News")
        self.assertEqual(settings["breaking_enabled"], "0")
        self.assertNotIn("బ్రేకింగ్ న్యూస్", self.client.get("/").data.decode("utf-8"))

    def test_routes_and_search(self):
        for path in (
            "/", "/andhra-pradesh", "/admin", "/admin/articles", "/admin/ads",
            "/admin/settings", "/epaper", "/photos", "/videos",
            "/api/articles?page=1", "/api/search?q=క్రికెట్",
        ):
            with self.subTest(path=path):
                self.assertEqual(self.client.get(path).status_code, 200)

    def test_gnan24_branding_and_old_settings_migration(self):
        self.assertEqual(db.get_settings()["site_name"], "gnan24")
        for path in ("/", "/admin", "/admin/settings", "/epaper", "/andhra-pradesh"):
            with self.subTest(path=path):
                response = self.client.get(path)
                self.assertEqual(response.status_code, 200)
                self.assertIn("gnan24", response.data.decode("utf-8"))

        homepage = self.client.get("/").data.decode("utf-8")
        self.assertIn('src="/static/gnan24-logo.png"', homepage)
        logo_response = self.client.get("/static/gnan24-logo.png")
        self.assertEqual(logo_response.status_code, 200)
        logo_response.close()

        article_form = self.client.get("/admin/articles/new").data.decode("utf-8")
        self.assertIn('<html lang="en">', article_form)
        visible_text = re.sub(r"<[^>]+>", " ", article_form)
        self.assertNotRegex(visible_text, r"[\u0c00-\u0c7f]")
        for english_label in ("New Article", "Title", "Category", "Author", "Save article"):
            self.assertIn(english_label, article_form)
        self.assertIn("Hyderabad", article_form)
        dashboard = self.client.get("/admin").data.decode("utf-8")
        for english_label in ("Dashboard", "Total articles", "Traffic Overview", "Manage advertising"):
            self.assertIn(english_label, dashboard)
        category_search = self.client.get("/admin/articles?q=Hyderabad").data.decode("utf-8")
        self.assertIn(">Hyderabad</td>", category_search)
        for path in ("/admin/ads", "/admin/settings"):
            response = self.client.get(path)
            self.assertEqual(response.status_code, 200)
            admin_text = re.sub(r"<[^>]+>", " ", response.data.decode("utf-8"))
            self.assertNotRegex(admin_text, r"[\u0c00-\u0c7f]")
            response.close()

        with db.connect() as connection:
            connection.execute(
                "UPDATE site_settings SET value='Telugu Today' WHERE key='site_name'"
            )
            connection.execute(
                "UPDATE site_settings SET value='Telugu Today — నిజమైన కథలు, మీ ప్రపంచం' "
                "WHERE key='seo_title'"
            )
            connection.execute(
                "UPDATE site_settings SET value='తెలుగు పాఠకుల కోసం ప్రాంతీయ వార్తలు, విశ్లేషణలు, క్రీడలు మరియు వినోదం.' "
                "WHERE key='seo_description'"
            )
            connection.execute(
                "UPDATE articles SET author='తెలుగు టుడే డెస్క్' WHERE id=(SELECT MIN(id) FROM articles)"
            )
        db.initialize_database()
        self.assertEqual(db.get_settings()["site_name"], "gnan24")
        self.assertTrue(db.get_settings()["seo_title"].startswith("gnan24"))
        self.assertTrue(db.get_settings()["seo_description"].startswith("Regional news"))
        first_seed = next(article for article in db.get_articles(True) if article["id"] == "1")
        self.assertEqual(first_seed["author"], "gnan24 Desk")


if __name__ == "__main__":
    unittest.main()